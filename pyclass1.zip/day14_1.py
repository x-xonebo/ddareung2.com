import numpy
import pandas

print('설치완료')