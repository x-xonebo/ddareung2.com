
print(random(1,46))